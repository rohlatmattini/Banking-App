import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/account_controller.dart';
import '../controller/report_controller.dart';

class ReportsPage extends StatelessWidget {
  final ReportController controller = Get.find<ReportController>();

  ReportsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text('التقارير والتحليلات', style: TextStyle(fontFamily: 'Cairo', color: Colors.white)),
        centerTitle: true,
        backgroundColor: Colors.teal,
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: controller.loadAllReports),
          PopupMenuButton<String>(
            onSelected: controller.exportReport,
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'PDF', child: Text('تصدير PDF')),
              PopupMenuItem(value: 'Excel', child: Text('تصدير Excel')),
              PopupMenuItem(value: 'CSV', child: Text('تصدير CSV')),
            ],
          ),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSystemSummaryCard(),
              const SizedBox(height: 20),
              _buildDailyReportsCard(),
              const SizedBox(height: 20),
              _buildAccountSummariesCard(),
            ],
          ),
        );
      }),
    );
  }

  // ==================== System Summary Card ====================
  Widget _buildSystemSummaryCard() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('ملخص النظام', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 3,
              childAspectRatio: 5,
              children: [
                _buildSummaryItem('إجمالي الحسابات', '${controller.systemSummary['totalAccounts'] ?? 0}'),
                _buildSummaryItem('الحسابات النشطة', '${controller.systemSummary['activeAccounts'] ?? 0}'),
                _buildSummaryItem('إجمالي الرصيد', '\$${controller.systemSummary['totalBalance']?.toStringAsFixed(2) ?? "0.00"}'),
                _buildSummaryItem('المعاملات اليوم', '${controller.systemSummary['todayTransactions'] ?? 0}'),
                _buildSummaryItem('وقت التشغيل', '${controller.systemSummary['systemUptime'] ?? "0%"}'),
                _buildSummaryItem('آخر نسخة احتياطية', _formatDate(controller.systemSummary['lastBackup'])),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryItem(String title, String value) {
    return Column(
      children: [
        Text(title, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ],
    );
  }

  // ==================== Daily Reports Card ====================
  Widget _buildDailyReportsCard() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('التقرير اليومي', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                IconButton(icon: const Icon(Icons.calendar_today), onPressed: _showDatePicker),
              ],
            ),
            const SizedBox(height: 10),
            if (controller.dailyReports.isEmpty)
              const Center(child: Text('لا توجد بيانات')),
            ...controller.dailyReports.map((report) => _buildDailyReportItem(report)),
          ],
        ),
      ),
    );
  }

  Widget _buildDailyReportItem(Map<String, dynamic> report) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('تاريخ: ${_formatDate(report['date'])}'),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildMetricItem('المعاملات', '${report['totalTransactions']}', Colors.teal),
                _buildMetricItem('الإيداعات', '\$${report['totalDeposits']?.toStringAsFixed(2) ?? "0.00"}', Colors.teal),
                _buildMetricItem('السحوبات', '\$${report['totalWithdrawals']?.toStringAsFixed(2) ?? "0.00"}', Colors.teal),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMetricItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(label, style: const TextStyle(fontSize: 12)),
        Text(value, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: color)),
      ],
    );
  }

  // ==================== Account Summaries Card ====================
  Widget _buildAccountSummariesCard() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('ملخصات الحسابات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal, // تمرير أفقي
              child: ConstrainedBox(
                constraints: BoxConstraints(minWidth: MediaQuery.of(Get.context!).size.width),
                child: DataTable(
                  columnSpacing: 30,
                  columns: const [
                    DataColumn(label: Text('النوع')),
                    DataColumn(label: Text('العدد')),
                    DataColumn(label: Text('إجمالي الرصيد')),
                    DataColumn(label: Text('متوسط الرصيد')),
                  ],
                  rows: controller.accountSummaries.map((summary) {
                    return DataRow(cells: [
                      DataCell(Text(_translateAccountType(summary['type']))),
                      DataCell(Text('${summary['count']}', style: const TextStyle(color: Colors.teal))),
                      DataCell(Text('\$${summary['totalBalance']?.toStringAsFixed(2) ?? "0.00"}', style: const TextStyle(color: Colors.teal))),
                      DataCell(Text('\$${summary['averageBalance']?.toStringAsFixed(2) ?? "0.00"}', style: const TextStyle(color: Colors.teal))),
                    ]);
                  }).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== Utility Methods ====================
  void _showDatePicker() {
    showDatePicker(
      context: Get.context!,
      initialDate: controller.selectedDate.value,
      firstDate: DateTime.now().subtract(const Duration(days: 30)),
      lastDate: DateTime.now(),
    ).then((date) {
      if (date != null) {
        controller.changeDate(date);
      }
    });
  }

  String _formatDate(dynamic date) {
    if (date is String) return DateTime.parse(date).toLocal().toString().split(' ')[0];
    return 'N/A';
  }

  String _formatTime(dynamic timestamp) {
    if (timestamp is String) {
      final time = DateTime.parse(timestamp).toLocal();
      return '${time.hour}:${time.minute.toString().padLeft(2, '0')}';
    }
    return '';
  }

  String _translateAccountType(String type) {
    switch (type) {
      case 'savings': return 'توفير';
      case 'checking': return 'جاري';
      case 'loan': return 'قرض';
      case 'investment': return 'استثمار';
      default: return type;
    }
  }
}

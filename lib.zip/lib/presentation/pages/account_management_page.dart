import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/account_controller.dart';
import '../widgets/account_card.dart';
import '../widgets/create_account_dialog.dart';

class AccountManagementPage extends StatelessWidget {
  final AccountController controller = Get.find<AccountController>();

  AccountManagementPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'إدارة الحسابات',
          style: TextStyle(
            fontFamily: 'Cairo',
            color: Colors.white
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.teal[700],
        elevation: 2,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: () => controller.fetchAccounts(),
            tooltip: 'تحديث',
          ),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text('جاري تحميل الحسابات...'),
              ],
            ),
          );
        }

        if (controller.accounts.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.account_balance_wallet,
                  size: 100,
                  color: Colors.grey[300],
                ),
                const SizedBox(height: 20),
                const Text(
                  'لا توجد حسابات',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'استخدم زر + لإنشاء حساب جديد',
                  style: TextStyle(color: Colors.grey),
                ),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: () => _showCreateAccountDialog(context),
                  icon: const Icon(Icons.add, color: Colors.teal),
                  label: const Text('إنشاء حساب جديد',style: TextStyle(color:Colors.teal),),
                ),
              ],
            ),
          );
        }

        final stats = controller.getAccountStatistics();

        return Column(
          children: [
            // إحصائيات الحسابات
            _buildStatisticsCard(stats),

            // قائمة الحسابات
            Expanded(
              child: RefreshIndicator(
                onRefresh: () => controller.fetchAccounts(),
                child: ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: controller.accounts.length,
                  itemBuilder: (context, index) {
                    final account = controller.accounts[index];
                    return AccountCard(
                      account: account,
                      controller: controller,
                    );
                  },
                ),
              ),
            ),
          ],
        );
      }),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateAccountDialog(context),
        icon: const Icon(Icons.add),
        label: const Text('حساب جديد'),
        backgroundColor: Colors.teal,
      ),
    );
  }

  Widget _buildStatisticsCard(Map<String, int> stats) {
    return Card(
      margin: const EdgeInsets.all(16),
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'إحصائيات الحسابات',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Chip(
                  label: Text(
                    '${stats['total']} حساب',
                    style: const TextStyle(color: Colors.white),
                  ),
                  backgroundColor: Colors.teal,
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildStatItem('إجمالي الأرصدة', stats['totalBalance'] ?? 0, true),
                _buildStatItem('نشطة', stats['active'] ?? 0, false),
                _buildStatItem('مجمدة', stats['frozen'] ?? 0, false),
                _buildStatItem('مغلقة', stats['closed'] ?? 0, false),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, int value, bool isMoney) {
    return Column(
      children: [
        Text(
          isMoney ? '\$$value' : value.toString(),
          style: TextStyle(
            fontSize: isMoney ? 16 : 18,
            fontWeight: FontWeight.bold,
            color: Colors.teal, // تغيير هذا السطر فقط - جعل اللون teal لجميع الأرقام
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.grey,
          ),
        ),
      ],
    );
  }

  void _showCreateAccountDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => CreateAccountDialog(
        onCreate: (holderName, balance, type) {
          controller.createAccount(
            holderName: holderName,
            type: type,
            initialBalance: balance,
          );
        },
      ),
    );
  }
}
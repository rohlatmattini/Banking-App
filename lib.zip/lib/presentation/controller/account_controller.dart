import 'package:get/get.dart';
import '../../ domain/entities/account_entity.dart';
import '../../ domain/repositories/account_repository.dart';
import '../../ domain/states/account_state.dart';
import '../../ domain/states/active_state.dart';
import '../../ domain/states/closed_state.dart';
import '../../ domain/states/frozen_state.dart';
import '../../ domain/states/suspended_state.dart';
import '../../data/model/account_model.dart';
import 'package:flutter/material.dart';

class AccountController extends GetxController {
  final AccountRepository repository;
  AccountController({required this.repository});

  final accounts = <AccountEntity>[].obs;
  final isLoading = true.obs;
  final selectedAccount = Rxn<AccountEntity>();

  @override
  void onInit() {
    fetchAccounts();
    super.onInit();
  }

  Future<void> fetchAccounts() async {
    isLoading.value = true;
    try {
      final result = await repository.getAccounts();
      accounts.assignAll(result);
    } catch (e) {
      Get.snackbar(
        'خطأ',
        'فشل تحميل الحسابات: ${e.toString()}',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> createAccount({
    required String holderName,
    required AccountType type,
    double initialBalance = 0.0,
  }) async {
    try {
      final newAccount = AccountModel.createNew(
        holderName: holderName,
        type: type,
        initialBalance: initialBalance,
      );

      await repository.createAccount(newAccount);
      await fetchAccounts();

      Get.snackbar(
        'نجاح',
        'تم إنشاء الحساب بنجاح',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } catch (e) {
      Get.snackbar(
        'خطأ',
        'فشل إنشاء الحساب: ${e.toString()}',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  // تغيير حالة الحساب - النسخة المحسنة
  Future<void> changeAccountState(String id, String newStateName) async {
    try {
      final account = accounts.firstWhere((acc) => acc.id == id);

      AccountState newState;
      String successMessage;

      switch (newStateName) {
        case 'active':
        case 'active':
          if (account.state.name == 'closed') {
            throw Exception('لا يمكن إعادة تفعيل حساب مغلق');
          }

          newState = ActiveState();
          account.activate();
          successMessage = 'تم تفعيل الحساب بنجاح';
          break;


        case 'frozen':
          newState = FrozenState();
          account.freeze();
          successMessage = 'تم تجميد الحساب بنجاح';
          break;

        case 'suspended':
          newState = SuspendedState();
          account.suspend();
          successMessage = 'تم إيقاف الحساب بنجاح';
          break;

        case 'closed':
        // التحقق من وجود رصيد صفري
          if (account.balance > 0) {
            throw Exception('لا يمكن إغلاق الحساب إلا إذا كان الرصيد صفر');
          }
          newState = ClosedState();
          account.close();
          successMessage = 'تم إغلاق الحساب بنجاح';
          break;

        default:
          throw Exception('حالة غير صالحة: $newStateName');
      }

      // تحديث الحالة
      account.changeState(newState);

      // تحديث في المستودع
      await repository.updateAccount(account);

      // تحديث القائمة
      final index = accounts.indexWhere((acc) => acc.id == id);
      if (index != -1) {
        accounts[index] = account;
      }

      Get.snackbar(
        'نجاح',
        successMessage,
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );

    } catch (e) {
      Get.snackbar(
        'خطأ',
        'فشل تغيير حالة الحساب: ${e.toString()}',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  // حذف حساب - النسخة المحسنة
  Future<void> deleteAccount(String id) async {
    try {
      final account = accounts.firstWhere((acc) => acc.id == id);

      // التحقق من إمكانية الحذف
      if (!account.canDelete) {
        throw Exception('لا يمكن حذف الحساب لأنه ${account.status}. يجب إغلاقه أولاً');
      }

      // تأكيد الحذف
      Get.defaultDialog(
        title: 'تأكيد الحذف',
        middleText: 'هل أنت متأكد من حذف حساب ${account.holderName}؟\nهذا الإجراء لا يمكن التراجع عنه.',
        textConfirm: 'نعم، احذف',
        textCancel: 'إلغاء',
        confirmTextColor: Colors.white,
        onConfirm: () async {
          Get.back();

          try {
            await repository.deleteAccount(id);
            accounts.removeWhere((acc) => acc.id == id);

            Get.snackbar(
              'نجاح',
              'تم حذف الحساب بنجاح',
              snackPosition: SnackPosition.BOTTOM,
              backgroundColor: Colors.green,
              colorText: Colors.white,
            );
          } catch (e) {
            Get.snackbar(
              'خطأ',
              'فشل حذف الحساب: ${e.toString()}',
              snackPosition: SnackPosition.BOTTOM,
              backgroundColor: Colors.red,
              colorText: Colors.white,
            );
          }
        },
      );

    } catch (e) {
      Get.snackbar(
        'خطأ',
        e.toString(),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  // إجراء إيداع
  Future<void> performDeposit(String id, double amount) async {
    try {
      await repository.deposit(id, amount);
      await fetchAccounts(); // إعادة تحميل للتحديث

      Get.snackbar(
        'نجاح',
        'تم إيداع المبلغ بنجاح',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } catch (e) {
      Get.snackbar(
        'خطأ',
        e.toString(),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  // إجراء سحب
  Future<void> performWithdraw(String id, double amount) async {
    try {
      await repository.withdraw(id, amount);
      await fetchAccounts(); // إعادة تحميل للتحديث

      Get.snackbar(
        'نجاح',
        'تم سحب المبلغ بنجاح',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } catch (e) {
      Get.snackbar(
        'خطأ',
        e.toString(),
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  // تحديد حساب
  void selectAccount(String id) {
    selectedAccount.value = accounts.firstWhere((acc) => acc.id == id);
  }

  // الحصول على حالة الحساب
  AccountState getAccountState(String id) {
    final account = accounts.firstWhere((acc) => acc.id == id);
    return account.state;
  }

  // إحصائيات الحسابات
  Map<String, int> getAccountStatistics() {
    Map<String, int> stats = {
      'total': accounts.length,
      'active': 0,
      'frozen': 0,
      'suspended': 0,
      'closed': 0,
      'totalBalance': 0,
    };

    for (var account in accounts) {
      stats['totalBalance'] = stats['totalBalance']! + account.balance.toInt();

      switch (account.state.name) {
        case 'active':
          stats['active'] = stats['active']! + 1;
          break;
        case 'frozen':
          stats['frozen'] = stats['frozen']! + 1;
          break;
        case 'suspended':
          stats['suspended'] = stats['suspended']! + 1;
          break;
        case 'closed':
          stats['closed'] = stats['closed']! + 1;
          break;
      }
    }

    return stats;
  }
}
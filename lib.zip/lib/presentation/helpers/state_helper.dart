import 'package:flutter/material.dart';
import '../../ domain/entities/account_entity.dart';
import '../../ domain/states/account_state.dart';


class StateHelper {
  static Color hexToColor(String hexColor) {
    hexColor = hexColor.replaceAll("#", "");
    if (hexColor.length == 6) {
      hexColor = "FF$hexColor";
    }
    return Color(int.parse(hexColor, radix: 16));
  }

  static IconData getIconForState(AccountState state) {
    switch (state.name) {
      case 'active':
        return Icons.check_circle;
      case 'frozen':
        return Icons.ac_unit;
      case 'suspended':
        return Icons.pause_circle;
      case 'closed':
        return Icons.cancel;
      default:
        return Icons.error;
    }
  }

  static Color getColorForState(AccountState state) {
    return hexToColor(state.colorHex);
  }

  static Color getColorForType(AccountType type) {
    return hexToColor(type.colorHex);
  }

  static IconData getIconForType(AccountType type) {
    switch (type) {
      case AccountType.savings:
        return Icons.savings;
      case AccountType.checking:
        return Icons.account_balance;
      case AccountType.loan:
        return Icons.money;
      case AccountType.investment:
        return Icons.trending_up;
      default:
        return Icons.account_balance_wallet;
    }
  }
}
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../ domain/entities/account_entity.dart';
import '../controller/account_controller.dart';
import '../helpers/state_helper.dart';

class AccountCard extends StatelessWidget {
  final AccountEntity account;
  final AccountController controller;

  const AccountCard({
    super.key,
    required this.account,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    final statusColor = StateHelper.hexToColor(account.statusColorHex);
    final typeColor = StateHelper.getColorForType(account.type);
    final statusIcon = StateHelper.getIconForState(account.state);

    return Card(
      elevation: 3,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        account.holderName,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'رقم الحساب: ${account.id.substring(0, 8)}...',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Chip(
                      label: Text(
                        account.type.arabicName,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                      backgroundColor: typeColor,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 2,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          Icons.calendar_today,
                          size: 12,
                          color: Colors.grey,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${account.createdDate.day}/${account.createdDate.month}/${account.createdDate.year}',
                          style: const TextStyle(
                            fontSize: 10,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 12),

            // Balance
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[50],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey[200]!),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'الرصيد الحالي:',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    '\$${account.balance.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontSize: 20,
                      color: Colors.teal,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            // State Section
            _buildStateSection(statusColor, statusIcon),

            const SizedBox(height: 12),

            // Operations
            _buildOperationsSection(),

            const SizedBox(height: 8),

            // Actions
            _buildActionsSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildStateSection(Color statusColor, IconData statusIcon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: statusColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: statusColor.withOpacity(0.3)),
          ),
          child: Row(
            children: [
              Icon(statusIcon, color: statusColor, size: 16),
              const SizedBox(width: 6),
              Text(
                account.status,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: statusColor,
                ),
              ),
            ],
          ),
        ),
        const Spacer(),
        if (account.canChangeState)
          IconButton(
            icon: Icon(Icons.sync, color: Colors.teal),
            onPressed: () => _showStateChangeDialog(),
            tooltip: 'تغيير الحالة',
          ),
      ],
    );
  }

  Widget _buildOperationsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'العمليات المتاحة:',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _buildOperationButton(
              'إيداع',
              account.canDeposit,
              Icons.add,
              Colors.grey,
                  () => _showOperationDialog('deposit'),
            ),
            _buildOperationButton(
              'سحب',
              account.canWithdraw,
              Icons.remove,
              Colors.grey,
                  () => _showOperationDialog('withdraw'),
            ),
            _buildOperationButton(
              'تحويل',
              account.canTransfer,
              Icons.swap_horiz,
              Colors.grey,
                  () => _showOperationDialog('transfer'),
            ),
            _buildOperationButton(
              'إغلاق',
              account.canClose,
              Icons.lock,
              Colors.grey,
                  () => controller.changeAccountState(account.id, 'closed'),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildOperationButton(
      String label,
      bool enabled,
      IconData icon,
      Color color,
      VoidCallback onPressed,
      ) {
    return ElevatedButton.icon(
      onPressed: enabled ? onPressed : null,
      icon: Icon(icon, size: 16),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        backgroundColor: enabled ? color : Colors.grey[300],
        foregroundColor: enabled ? Colors.white : Colors.grey[500],
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        minimumSize: const Size(0, 36),
      ),
    );
  }

  Widget _buildActionsSection() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        // if (account.canModify)
        //   OutlinedButton.icon(
        //     onPressed: () => _showEditDialog(),
        //     icon: const Icon(Icons.edit, size: 16),
        //     label: const Text('تعديل'),
        //     style: OutlinedButton.styleFrom(
        //       foregroundColor: Colors.blue,
        //       side: const BorderSide(color: Colors.blue),
        //     ),
        //   ),
        const SizedBox(width: 8),
        ElevatedButton.icon(
          onPressed: account.canDelete
              ? () => controller.deleteAccount(account.id)
              : null,
          icon: const Icon(Icons.delete, size: 16),
          label: const Text('حذف'),
          style: ElevatedButton.styleFrom(
            backgroundColor: account.canDelete ? Colors.red : Colors.grey[300],
            foregroundColor: Colors.white,
          ),
        ),
      ],
    );
  }

  void _showStateChangeDialog() {
    final currentState = account.state;

    Get.bottomSheet(
      Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'تغيير حالة الحساب',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'الحساب: ${account.holderName}',
              style: const TextStyle(color: Colors.grey),
            ),
            Text(
              'الحالة الحالية: ${account.status}',
              style: const TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 20),
            const Text(
              'اختر الحالة الجديدة:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            // Active State
            if (currentState.name != 'active' && currentState.name != 'closed')
              ListTile(
                leading: const Icon(Icons.check_circle, color: Colors.teal),
                title: const Text('تفعيل'),
                subtitle: const Text('جعل الحساب نشطًا'),
                onTap: () {
                  Get.back();
                  controller.changeAccountState(account.id, 'active');
                },
                tileColor: Colors.green[50],
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),

            // Frozen State
            if (currentState.name != 'frozen' && currentState.name != 'closed')
              ListTile(
                leading: const Icon(Icons.ac_unit, color: Colors.blue),
                title: const Text('تجميد'),
                subtitle: const Text('الإيداعات فقط مسموحة'),
                onTap: () {
                  Get.back();
                  controller.changeAccountState(account.id, 'frozen');
                },
                tileColor: Colors.blue[50],
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),

            // Suspended State
            if (currentState.name != 'suspended' && currentState.name != 'closed')
              ListTile(
                leading: const Icon(Icons.pause_circle, color: Colors.orange),
                title: const Text('إيقاف'),
                subtitle: const Text('جميع العمليات متوقفة'),
                onTap: () {
                  Get.back();
                  controller.changeAccountState(account.id, 'suspended');
                },
                tileColor: Colors.orange[50],
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),

            // Closed State
            if (currentState.name != 'closed' && account.canClose)
              ListTile(
                leading: const Icon(Icons.cancel, color: Colors.red),
                title: const Text('إغلاق'),
                subtitle: const Text('إغلاق الحساب نهائيًا'),
                onTap: () {
                  Get.back();
                  controller.changeAccountState(account.id, 'closed');
                },
                tileColor: Colors.red[50],
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),

            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: Get.back,
                child: const Text('إلغاء',style: TextStyle(color: Colors.teal),),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showOperationDialog(String operation) {
    final amountController = TextEditingController();
    final formKey = GlobalKey<FormState>();

    Get.dialog(
      AlertDialog(
        title: Text(
          operation == 'deposit'
              ? 'إيداع'
              : operation == 'withdraw'
              ? 'سحب'
              : 'تحويل',
        ),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('الحساب: ${account.holderName}',style: TextStyle(color: Colors.teal),),
              Text('الرصيد الحالي: \$${account.balance.toStringAsFixed(2)}'),
              const SizedBox(height: 16),
              TextFormField(
                controller: amountController,
                decoration: InputDecoration(
                  labelText: 'المبلغ',
                  prefixIcon: const Icon(Icons.attach_money),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'الرجاء إدخال المبلغ';
                  }
                  final amount = double.tryParse(value);
                  if (amount == null || amount <= 0) {
                    return 'الرجاء إدخال مبلغ صحيح أكبر من الصفر';
                  }
                  if (operation == 'withdraw' && amount > account.balance) {
                    return 'المبلغ أكبر من الرصيد المتاح';
                  }
                  return null;
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: Get.back,
            child: const Text('إلغاء',style: TextStyle(color: Colors.teal)),
          ),
          ElevatedButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                final amount = double.parse(amountController.text);
                Get.back();

                if (operation == 'deposit') {
                  controller.performDeposit(account.id, amount);
                } else if (operation == 'withdraw') {
                  controller.performWithdraw(account.id, amount);
                }
              }
            },
            child: const Text('تنفيذ',style: TextStyle(color: Colors.teal)),
          ),
        ],
      ),
    );
  }

  // void _showEditDialog() {
  //   // يمكنك إضافة ميزة التعديل هنا
  //   Get.defaultDialog(
  //     title: 'تعديل الحساب',
  //     content: const Column(
  //       children: [
  //         Icon(Icons.build, size: 50, color: Colors.blue),
  //         SizedBox(height: 16),
  //         Text('ميزة التعديل قيد التطوير'),
  //       ],
  //     ),
  //     textConfirm: 'موافق',
  //     onConfirm: Get.back,
  //   );
  // }
}
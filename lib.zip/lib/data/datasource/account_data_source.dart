import '../../ domain/entities/account_entity.dart';

abstract class AccountDataSource {
  Future<List<AccountEntity>> fetchAccounts();
  Future<AccountEntity> fetchAccount(String id);
  Future<void> addAccount(AccountEntity account);
  Future<void> updateAccount(AccountEntity account);
  Future<void> removeAccount(String id);
  Future<void> clearAllAccounts();
}
import '../../ domain/entities/account_entity.dart';
import 'account_data_source.dart';
import '../model/account_model.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart'as http;

class LocalAccountDataSource implements AccountDataSource {
  static const String _accountsKey = 'banking_accounts';

  final List<AccountEntity> _accounts = [];

  LocalAccountDataSource() {
    _loadAccounts();
  }

  Future<void> _loadAccounts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final accountsJson = prefs.getString(_accountsKey);

      if (accountsJson != null) {
        final List<dynamic> accountsList = json.decode(accountsJson);
        _accounts.clear();
        _accounts.addAll(
            accountsList.map((json) => AccountModel.fromJson(json)).toList()
        );
      }
    } catch (e) {
      print('Error loading accounts: $e');
    }
  }
  //
  // Future<void> _saveAccounts() async {
  //   try {
  //     final prefs = await SharedPreferences.getInstance();
  //     final accountsJson = json.encode(
  //         _accounts.map((account) => account.toJson()).toList()
  //     );
  //     await prefs.setString(_accountsKey, accountsJson);
  //   } catch (e) {
  //     print('Error saving accounts: $e');
  //   }
  // }

  @override
  Future<List<AccountEntity>> fetchAccounts() async {
    await _loadAccounts();
    return List.from(_accounts);
  }

  @override
  Future<AccountEntity> fetchAccount(String id) async {
    await _loadAccounts();
    final account = _accounts.firstWhere(
            (acc) => acc.id == id,
        orElse: () => throw Exception('الحساب غير موجود: $id')
    );
    return account;
  }

  @override
  Future<void> addAccount(AccountEntity account) async {
    await _loadAccounts();

    // التحقق من عدم وجود حساب بنفس الهوية
    if (_accounts.any((acc) => acc.id == account.id)) {
      throw Exception('الحساب موجود مسبقاً');
    }

    _accounts.add(account);
    // await _saveAccounts();
  }

  @override
  Future<void> updateAccount(AccountEntity account) async {
    await _loadAccounts();

    final index = _accounts.indexWhere((acc) => acc.id == account.id);
    if (index == -1) {
      throw Exception('الحساب غير موجود: ${account.id}');
    }

    _accounts[index] = account;
    // await _saveAccounts();
  }

  @override
  Future<void> removeAccount(String id) async {
    await _loadAccounts();

    final account = _accounts.firstWhere(
            (acc) => acc.id == id,
        orElse: () => throw Exception('الحساب غير موجود: $id')
    );

    // التحقق من إمكانية الحذف
    if (!account.canDelete) {
      throw Exception('لا يمكن حذف الحساب لأنه ${account.status}');
    }

    _accounts.removeWhere((acc) => acc.id == id);
    // await _saveAccounts();
  }

  @override
  Future<void> clearAllAccounts() async {
    _accounts.clear();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_accountsKey);
  }
}
import '../../ domain/entities/account_entity.dart';
import '../../ domain/states/account_state.dart';
import '../../ domain/states/active_state.dart';
import '../../ domain/states/closed_state.dart';
import '../../ domain/states/frozen_state.dart';
import '../../ domain/states/suspended_state.dart';


class AccountModel extends AccountEntity {
  AccountModel({
    required String id,
    required String holderName,
    required double balance,
    required AccountType type,
    AccountState? state,
    DateTime? createdDate,
    List<Transaction>? transactions,
  }) : super(
    id: id,
    holderName: holderName,
    balance: balance,
    type: type,
    state: state,
    createdDate: createdDate,
    transactions: transactions,
  );

  factory AccountModel.fromJson(Map<String, dynamic> json) {
    // تحديد الحالة من JSON
    AccountState state;
    switch (json['status']) {
      case 'frozen':
        state = FrozenState();
        break;
      case 'suspended':
        state = SuspendedState();
        break;
      case 'closed':
        state = ClosedState();
        break;
      default:
        state = ActiveState();
    }

    // تحويل قائمة المعاملات
    List<Transaction> transactions = [];
    if (json['transactions'] != null) {
      final transactionsList = json['transactions'] as List;
      transactions = transactionsList.map((t) => Transaction.fromJson(t)).toList();
    }

    return AccountModel(
      id: json['id'],
      holderName: json['holderName'],
      balance: json['balance'].toDouble(),
      type: AccountType.values[json['type']],
      state: state,
      createdDate: DateTime.parse(json['createdDate']),
      transactions: transactions,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'holderName': holderName,
      'balance': balance,
      'type': type.index,
      'status': state.name,
      'createdDate': createdDate.toIso8601String(),
      'transactions': transactions.map((t) => t.toJson()).toList(),
    };
  }

  factory AccountModel.createNew({
    required String holderName,
    required AccountType type,
    double initialBalance = 0.0,
  }) {
    return AccountModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      holderName: holderName,
      balance: initialBalance,
      type: type,
      state: ActiveState(),
      createdDate: DateTime.now(),
    );
  }

  // نسخ الحساب مع تحديثات
  AccountModel copyWith({
    String? id,
    String? holderName,
    double? balance,
    AccountType? type,
    AccountState? state,
    DateTime? createdDate,
    List<Transaction>? transactions,
  }) {
    return AccountModel(
      id: id ?? this.id,
      holderName: holderName ?? this.holderName,
      balance: balance ?? this.balance,
      type: type ?? this.type,
      state: state ?? this.state,
      createdDate: createdDate ?? this.createdDate,
      transactions: transactions ?? this.transactions,
    );
  }
}
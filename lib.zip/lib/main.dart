import 'package:flutter/material.dart';
import 'package:get/get.dart';

// Data Layer
import ' domain/repositories/account_repository_impl.dart';
import ' domain/repositories/report_repository_impl.dart';
import 'data/datasource/local_account_data_source.dart';


// Presentation Layer
import 'presentation/controller/account_controller.dart';
import 'presentation/controller/report_controller.dart';
import 'presentation/pages/home_page.dart';
import 'presentation/pages/account_management_page.dart';
import 'presentation/pages/reports_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'نظام البنك المتقدم',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        fontFamily: 'Cairo',
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 2,
          backgroundColor: Colors.teal,
        ),
        drawerTheme: const DrawerThemeData(
          backgroundColor: Colors.white,
        ),

        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Colors.teal,
          foregroundColor: Colors.white,
        ),
        chipTheme: ChipThemeData(
          backgroundColor: Colors.teal.shade50,
          labelStyle: const TextStyle(color: Colors.teal),
        ),
      ),

      // تهيئة Controllers قبل بناء التطبيق
      initialBinding: AppBindings(),
      getPages: [
        GetPage(name: '/', page: () => HomePage()),
        GetPage(name: '/accounts', page: () => AccountManagementPage()),
        GetPage(name: '/reports', page: () => ReportsPage()),
      ],
      home: HomePage(),
    );
  }
}

// Binding class لتهيئة جميع الـ Controllers
class AppBindings extends Bindings {
  @override
  void dependencies() {
    // إنشاء الـ DataSource والـ Repository
    final accountDataSource = LocalAccountDataSource();
    final accountRepository = AccountRepositoryImpl(dataSource: accountDataSource);
    final reportRepository = ReportRepositoryImpl();

    // تسجيل الـ Controllers
    Get.lazyPut(() => AccountController(repository: accountRepository), fenix: true);
    Get.lazyPut(() => ReportController(repository: reportRepository), fenix: true);
  }
}
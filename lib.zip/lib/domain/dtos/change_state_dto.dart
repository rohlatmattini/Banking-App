// lib/domain/dtos/change_state_dto.dart
class ChangeStateData {
  final String targetState;

  ChangeStateData({required this.targetState});
}
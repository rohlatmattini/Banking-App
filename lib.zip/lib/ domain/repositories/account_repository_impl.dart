import '../../data/datasource/account_data_source.dart';
import '../entities/account_entity.dart';
import '../states/account_state.dart';
import 'account_repository.dart';

class AccountRepositoryImpl implements AccountRepository {
  final AccountDataSource dataSource;

  AccountRepositoryImpl({required this.dataSource});

  @override
  Future<List<AccountEntity>> getAccounts() async {
    return await dataSource.fetchAccounts();
  }

  @override
  Future<AccountEntity> getAccountById(String id) async {
    return await dataSource.fetchAccount(id);
  }

  @override
  Future<void> createAccount(AccountEntity account) async {
    await dataSource.addAccount(account);
  }

  @override
  Future<void> updateAccount(AccountEntity account) async {
    await dataSource.updateAccount(account);
  }

  @override
  Future<void> deleteAccount(String id) async {
    await dataSource.removeAccount(id);
  }

  @override
  Future<void> changeAccountState(String id, AccountState newState) async {
    final account = await dataSource.fetchAccount(id);

    // تغيير الحالة
    account.changeState(newState);

    // حفظ التغييرات
    await dataSource.updateAccount(account);
  }

  @override
  Future<void> deposit(String id, double amount) async {
    final account = await dataSource.fetchAccount(id);

    // تنفيذ الإيداع
    account.deposit(amount);

    // حفظ التغييرات
    await dataSource.updateAccount(account);
  }

  @override
  Future<void> withdraw(String id, double amount) async {
    final account = await dataSource.fetchAccount(id);

    // تنفيذ السحب
    account.withdraw(amount);

    // حفظ التغييرات
    await dataSource.updateAccount(account);
  }
}
import '../entities/report_component.dart';
import '../entities/account_entity.dart';

abstract class ReportRepository {
  Future<ReportComponent> buildAccountHierarchy(List<AccountEntity> accounts);
  Future<List<Map<String, dynamic>>> getDailyReport(DateTime date);
  Future<List<Map<String, dynamic>>> getAccountSummaries();
  Future<List<Map<String, dynamic>>> getAuditLogs();
  Future<Map<String, dynamic>> getSystemSummary();
}

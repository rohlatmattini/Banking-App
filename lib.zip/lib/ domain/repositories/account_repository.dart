import '../entities/account_entity.dart';
import '../states/account_state.dart';

abstract class AccountRepository {
  Future<List<AccountEntity>> getAccounts();
  Future<AccountEntity> getAccountById(String id);
  Future<void> createAccount(AccountEntity account);
  Future<void> updateAccount(AccountEntity account);
  Future<void> deleteAccount(String id);
  Future<void> changeAccountState(String id, AccountState newState);
  Future<void> deposit(String id, double amount);
  Future<void> withdraw(String id, double amount);
}
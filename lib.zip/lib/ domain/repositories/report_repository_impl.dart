import 'report_repository.dart';
import '../entities/account_entity.dart';
import '../entities/account_group_composite.dart';
import '../entities/account_report_leaf.dart';
import '../entities/report_component.dart';

class ReportRepositoryImpl implements ReportRepository {
  @override
  Future<ReportComponent> buildAccountHierarchy(List<AccountEntity> accounts) async {
    final familyGroup = AccountGroupComposite('Family Accounts');
    final businessGroup = AccountGroupComposite('Business Accounts');
    final personalGroup = AccountGroupComposite('Personal Accounts');

    for (var account in accounts) {
      final leaf = AccountReportLeaf(account);

      if (account.holderName.contains('Family')) {
        familyGroup.add(leaf);
      } else if (account.holderName.contains('Co') || account.holderName.contains('Ltd')) {
        businessGroup.add(leaf);
      } else {
        personalGroup.add(leaf);
      }
    }

    final rootGroup = AccountGroupComposite('All Accounts');
    rootGroup.add(familyGroup);
    rootGroup.add(businessGroup);
    rootGroup.add(personalGroup);

    return rootGroup;
  }

  @override
  Future<List<Map<String, dynamic>>> getDailyReport(DateTime date) async {
    return [
      {
        'date': date.toIso8601String(),
        'totalTransactions': 150,
        'totalDeposits': 50000.0,
        'totalWithdrawals': 25000.0,
        'newAccounts': 3,
        'closedAccounts': 1,
      },
      {
        'date': date.subtract(const Duration(days: 1)).toIso8601String(),
        'totalTransactions': 120,
        'totalDeposits': 45000.0,
        'totalWithdrawals': 22000.0,
        'newAccounts': 2,
        'closedAccounts': 0,
      }
    ];
  }

  @override
  Future<List<Map<String, dynamic>>> getAccountSummaries() async {
    return [
      {'type': 'savings', 'count': 25, 'totalBalance': 500000.0, 'averageBalance': 20000.0},
      {'type': 'checking', 'count': 40, 'totalBalance': 800000.0, 'averageBalance': 20000.0},
      {'type': 'loan', 'count': 15, 'totalBalance': -300000.0, 'averageBalance': -20000.0},
      {'type': 'investment', 'count': 10, 'totalBalance': 1000000.0, 'averageBalance': 100000.0},
    ];
  }

  @override
  Future<List<Map<String, dynamic>>> getAuditLogs() async {
    return [
      {'id': '1', 'timestamp': DateTime.now().toIso8601String(), 'user': 'admin', 'action': 'LOGIN', 'details': 'User logged in', 'ip': '192.168.1.1'},
      {'id': '2', 'timestamp': DateTime.now().subtract(const Duration(hours: 1)).toIso8601String(), 'user': 'manager', 'action': 'ACCOUNT_CREATE', 'details': 'Created new savings account', 'ip': '192.168.1.2'},
      {'id': '3', 'timestamp': DateTime.now().subtract(const Duration(hours: 2)).toIso8601String(), 'user': 'teller', 'action': 'TRANSACTION_PROCESS', 'details': 'Processed deposit of \$5000', 'ip': '192.168.1.3'},
      {'id': '4', 'timestamp': DateTime.now().subtract(const Duration(hours: 3)).toIso8601String(), 'user': 'admin', 'action': 'REPORT_GENERATE', 'details': 'Generated daily report', 'ip': '192.168.1.1'},
    ];
  }

  @override
  Future<Map<String, dynamic>> getSystemSummary() async {
    return {
      'totalAccounts': 90,
      'activeAccounts': 85,
      'totalBalance': 2000000.0,
      'todayTransactions': 150,
      'todayDeposits': 50000.0,
      'todayWithdrawals': 25000.0,
      'systemUptime': '99.8%',
      'lastBackup': DateTime.now().subtract(const Duration(hours: 6)).toIso8601String(),
    };
  }
}

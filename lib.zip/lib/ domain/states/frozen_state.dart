import 'account_state.dart';
import 'active_state.dart';
import 'closed_state.dart';
import 'suspended_state.dart';

class FrozenState implements AccountState {
  @override
  String get name => 'frozen';

  @override
  String get arabicName => 'مجمد';

  @override
  String get colorHex => '#009688';

  @override
  String get iconCodePoint => 'e1ca';

  @override
  bool get canDeposit => true;

  @override
  bool get canWithdraw => false;

  @override
  bool get canTransfer => false;

  @override
  bool get canModify => false;

  @override
  bool get canClose => true;

  @override
  bool get canDelete => false;

  // ✅ جديد
  @override
  bool get canChangeState => true;

  @override
  AccountState activate() => ActiveState();

  @override
  AccountState freeze() => this;

  @override
  AccountState suspend() => SuspendedState();

  @override
  AccountState close() => ClosedState();

  @override
  String performDeposit(double amount, double currentBalance) {
    return 'تم الإيداع في حساب مجمد';
  }

  @override
  String performWithdrawal(double amount, double currentBalance) {
    throw StateError('الحساب مجمد');
  }

  @override
  String performTransfer(double amount) {
    throw StateError('الحساب مجمد');
  }
}

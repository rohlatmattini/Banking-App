abstract class AccountState {
  // معلومات الحالة
  String get name;
  String get arabicName;
  String get colorHex;
  String get iconCodePoint;

  // العمليات المسموحة
  bool get canDeposit;
  bool get canWithdraw;
  bool get canTransfer;
  bool get canModify;
  bool get canClose;
  bool get canDelete;

  // ✅ صلاحية تغيير الحالة (جديدة)
  bool get canChangeState;

  // انتقالات الحالة
  AccountState activate();
  AccountState freeze();
  AccountState suspend();
  AccountState close();

  // إجراءات بناءً على الحالة
  String performDeposit(double amount, double currentBalance);
  String performWithdrawal(double amount, double currentBalance);
  String performTransfer(double amount);
}

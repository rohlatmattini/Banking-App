import 'account_state.dart';
import 'closed_state.dart';
import 'frozen_state.dart';
import 'suspended_state.dart';

class ActiveState implements AccountState {
  @override
  String get name => 'active';

  @override
  String get arabicName => 'نشط';

  @override
  String get colorHex => '#009688';

  @override
  String get iconCodePoint => '#009688';

  @override
  bool get canDeposit => true;

  @override
  bool get canWithdraw => true;

  @override
  bool get canTransfer => true;

  @override
  bool get canModify => true;

  @override
  bool get canClose => true;

  @override
  bool get canDelete => false;

  // ✅ جديد
  @override
  bool get canChangeState => true;

  @override
  AccountState activate() => this;

  @override
  AccountState freeze() => FrozenState();

  @override
  AccountState suspend() => SuspendedState();

  @override
  AccountState close() => ClosedState();

  @override
  String performDeposit(double amount, double currentBalance) {
    return 'تم إيداع \$${amount.toStringAsFixed(2)} بنجاح';
  }

  @override
  String performWithdrawal(double amount, double currentBalance) {
    if (amount > currentBalance) {
      throw StateError('رصيد غير كافي');
    }
    return 'تم السحب بنجاح';
  }

  @override
  String performTransfer(double amount) {
    return 'تم التحويل';
  }
}

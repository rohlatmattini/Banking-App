import 'account_state.dart';
import 'active_state.dart';
import 'closed_state.dart';
import 'frozen_state.dart';

class SuspendedState implements AccountState {
  @override
  String get name => 'suspended';

  @override
  String get arabicName => 'موقوف';

  @override
  String get colorHex => '#009688';

  @override
  String get iconCodePoint => 'e034';

  @override
  bool get canDeposit => false;

  @override
  bool get canWithdraw => false;

  @override
  bool get canTransfer => false;

  @override
  bool get canModify => false;

  @override
  bool get canClose => true;

  @override
  bool get canDelete => false;

  // ✅ جديد
  @override
  bool get canChangeState => true;

  @override
  AccountState activate() => ActiveState();

  @override
  AccountState freeze() => FrozenState();

  @override
  AccountState suspend() => this;

  @override
  AccountState close() => ClosedState();

  @override
  String performDeposit(double amount, double currentBalance) {
    throw StateError('الحساب موقوف');
  }

  @override
  String performWithdrawal(double amount, double currentBalance) {
    throw StateError('الحساب موقوف');
  }

  @override
  String performTransfer(double amount) {
    throw StateError('الحساب موقوف');
  }
}

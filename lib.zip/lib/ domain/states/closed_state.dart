import 'account_state.dart';
import 'active_state.dart';

class ClosedState implements AccountState {
  @override
  String get name => 'closed';

  @override
  String get arabicName => 'مغلق';

  @override
  String get colorHex => '#F44336';

  @override
  String get iconCodePoint => 'e5c9';

  @override
  bool get canDeposit => false;

  @override
  bool get canWithdraw => false;

  @override
  bool get canTransfer => false;

  @override
  bool get canModify => false;

  @override
  bool get canClose => false;

  @override
  bool get canDelete => true;

  // ✅ جديد
  @override
  bool get canChangeState => false;

  @override
  AccountState activate() {
    throw StateError('لا يمكن تفعيل حساب مغلق');
  }

  @override
  AccountState freeze() => this;

  @override
  AccountState suspend() => this;

  @override
  AccountState close() => this;

  @override
  String performDeposit(double amount, double currentBalance) {
    throw StateError('الحساب مغلق');
  }

  @override
  String performWithdrawal(double amount, double currentBalance) {
    throw StateError('الحساب مغلق');
  }

  @override
  String performTransfer(double amount) {
    throw StateError('الحساب مغلق');
  }
}

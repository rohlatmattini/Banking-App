import 'report_component.dart';
import 'account_entity.dart';

class AccountReportLeaf implements ReportComponent {
  final AccountEntity account;

  AccountReportLeaf(this.account);

  @override
  String getName() => account.holderName;

  @override
  double getBalance() => account.balance;

  @override
  List<Map<String, dynamic>> generateReport() {
    return [
      {
        'type': 'account',
        'id': account.id,
        'name': account.holderName,
        'accountType': account.type.toString().split('.').last,
        'balance': account.balance,
        'status': account.status.toString().split('.').last,
        'date': DateTime.now().toIso8601String(),
      }
    ];
  }

  @override
  void add(ReportComponent component) {
    throw UnsupportedError('Cannot add to leaf');
  }

  @override
  void remove(ReportComponent component) {
    throw UnsupportedError('Cannot remove from leaf');
  }

  @override
  List<ReportComponent> getChildren() => [];
}

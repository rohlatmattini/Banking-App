import '../states/account_state.dart';
import '../states/active_state.dart';

abstract class AccountEntity {
  final String id;
  final String holderName;
  double balance; // تغيير من final لتعديل الرصيد
  final DateTime createdDate;
  final AccountType type;
  AccountState state;
  final List<Transaction> transactions; // سجل المعاملات

  AccountEntity({
    required this.id,
    required this.holderName,
    required this.balance,
    required this.type,
    AccountState? state,
    DateTime? createdDate,
    List<Transaction>? transactions,
  })  : state = state ?? ActiveState(),
        createdDate = createdDate ?? DateTime.now(),
        transactions = transactions ?? [];

  // State delegation methods
  String get status => state.arabicName;
  String get statusColorHex => state.colorHex;
  String get statusIconCodePoint => state.iconCodePoint;

  // State-based operation checks
  bool get canDeposit => state.canDeposit;
  bool get canWithdraw => state.canWithdraw;
  bool get canTransfer => state.canTransfer;
  bool get canModify => state.canModify;
  bool get canClose => state.canClose;
  bool get canDelete => state.canDelete;
  bool get canChangeState => state.canChangeState;



  // State transition methods
  void changeState(AccountState newState) {
    state = newState;
  }

  void activate() => state = state.activate();
  void freeze() => state = state.freeze();
  void suspend() => state = state.suspend();
  void close() => state = state.close();

  // Business operations with state validation
  String deposit(double amount) {
    if (!canDeposit) {
      throw StateError('لا يمكن الإيداع: الحساب ${status}');
    }

    final message = state.performDeposit(amount, balance);
    balance += amount; // تحديث الرصيد

    // تسجيل المعاملة
    transactions.add(Transaction(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      type: TransactionType.deposit,
      amount: amount,
      date: DateTime.now(),
      description: message,
      balanceAfter: balance,
    ));

    return message;
  }

  String withdraw(double amount) {
    if (!canWithdraw) {
      throw StateError('لا يمكن السحب: الحساب ${status}');
    }

    final message = state.performWithdrawal(amount, balance);
    balance -= amount; // تحديث الرصيد

    // تسجيل المعاملة
    transactions.add(Transaction(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      type: TransactionType.withdrawal,
      amount: amount,
      date: DateTime.now(),
      description: message,
      balanceAfter: balance,
    ));

    return message;
  }

  String transfer(double amount) {
    if (!canTransfer) {
      throw StateError('لا يمكن التحويل: الحساب ${status}');
    }

    final message = state.performTransfer(amount);
    // في حالة التحويل الحقيقي، تحتاج لحسابين: مرسل ومستقبل

    return message;
  }
}

enum AccountType {
  savings('توفير', '#009688'), // Green
  checking('جاري', '#009688'), // Blue
  loan('قرض', '#009688'), // Orange
  investment('استثمار', '#009688'); // Purple

  final String arabicName;
  final String colorHex;
  const AccountType(this.arabicName, this.colorHex);
}

enum TransactionType {
  deposit('إيداع'),
  withdrawal('سحب'),
  transfer('تحويل'),
  interest('فائدة'),
  fee('رسوم');

  final String arabicName;
  const TransactionType(this.arabicName);
}

class Transaction {
  final String id;
  final TransactionType type;
  final double amount;
  final DateTime date;
  final String description;
  final double balanceAfter;

  Transaction({
    required this.id,
    required this.type,
    required this.amount,
    required this.date,
    required this.description,
    required this.balanceAfter,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type.name,
      'amount': amount,
      'date': date.toIso8601String(),
      'description': description,
      'balanceAfter': balanceAfter,
    };
  }

  factory Transaction.fromJson(Map<String, dynamic> json) {
    return Transaction(
      id: json['id'],
      type: TransactionType.values.firstWhere(
            (e) => e.name == json['type'],
        orElse: () => TransactionType.deposit,
      ),
      amount: json['amount'].toDouble(),
      date: DateTime.parse(json['date']),
      description: json['description'],
      balanceAfter: json['balanceAfter'].toDouble(),
    );
  }

}
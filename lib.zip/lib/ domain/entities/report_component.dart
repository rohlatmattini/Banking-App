abstract class ReportComponent {
  String getName();
  double getBalance();
  List<Map<String, dynamic>> generateReport();
  void add(ReportComponent component);
  void remove(ReportComponent component);
  List<ReportComponent> getChildren();
}

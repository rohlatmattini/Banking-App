import 'report_component.dart';

class AccountGroupComposite implements ReportComponent {
  final String groupName;
  final List<ReportComponent> _children = [];

  AccountGroupComposite(this.groupName);

  @override
  String getName() => groupName;

  @override
  double getBalance() {
    double total = 0;
    for (var child in _children) {
      total += child.getBalance();
    }
    return total;
  }

  @override
  List<Map<String, dynamic>> generateReport() {
    List<Map<String, dynamic>> report = [];

    // إضافة معلومات المجموعة
    report.add({
      'type': 'group',
      'name': groupName,
      'totalBalance': getBalance(),
      'accountCount': _children.length,
      'children': _children.map((c) => c.generateReport().first).toList(),
      'date': DateTime.now().toIso8601String(),
    });

    // إضافة معلومات جميع الحسابات في المجموعة
    for (var child in _children) {
      report.addAll(child.generateReport());
    }

    return report;
  }

  @override
  void add(ReportComponent component) {
    _children.add(component);
  }

  @override
  void remove(ReportComponent component) {
    _children.remove(component);
  }

  @override
  List<ReportComponent> getChildren() => List.from(_children);
}
